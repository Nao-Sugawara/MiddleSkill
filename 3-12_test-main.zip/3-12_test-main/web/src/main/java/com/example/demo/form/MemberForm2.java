package com.example.demo.form;

import lombok.Data;

@Data
public class MemberForm2 {
	
	   private String name;
	   
}
